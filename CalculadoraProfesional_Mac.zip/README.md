# Calculadora Profesional para macOS

## 🍎 Instalación Rápida

1. **Abre Terminal** en esta carpeta
2. **Ejecuta:**
   ```bash
   chmod +x instalar_mac.sh
   ./instalar_mac.sh
   ```
3. **¡Listo!** Busca "Calculadora Profesional" en tu carpeta Aplicaciones

## 📋 Requisitos

- **macOS 10.13** o superior
- **Python 3.6+** con tkinter

### Instalar Python con tkinter:

**Opción 1 - Homebrew (Recomendado):**
```bash
brew install python-tk@3.11
```

**Opción 2 - Python.org:**
1. Descarga Python desde https://www.python.org/downloads/
2. Instala (incluye tkinter por defecto)

## ✨ Características

- ✅ Números negativos: `-5`, `3×(-2)`
- ✅ Operador de potencia `^`: `2^3`, `5^(-1)`
- ✅ Paréntesis: `(5+3)^2`
- ✅ Modo científico completo
- ✅ Constantes: π y e
- ✅ Atajos de teclado

## 🗑️ Desinstalar

Ejecuta:
```bash
~/Library/Application\ Support/CalculadoraProfesional/desinstalar.command
```

## 🆘 Problemas Comunes

### "tkinter no está disponible"
```bash
brew install python-tk@3.11
```

### "Permiso denegado"
```bash
chmod +x instalar_mac.sh
```

### La app no abre
Haz clic derecho → Abrir (primera vez en macOS Catalina+)

---

**¡Disfruta tu calculadora científica en Mac!** 🧮
